#データの書き出しPG
from bs4 import BeautifulSoup as bs
import requests as req
import time
import pandas as pd

url = input("商品ページのURL:")
data = pd.read_html(url,header=1,index_col=1)
file_name = input("ファイル名")+".csv"
data[0].to_csv(file_name,encoding="utf-8-sig")